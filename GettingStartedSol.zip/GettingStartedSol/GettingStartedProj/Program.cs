﻿using ExcelDna.Integration.CustomUI;
using ExcelDna.Integration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using ExcelApp = Microsoft.Office.Interop.Excel.Application;
using Microsoft.Office.Interop.Excel;

namespace GettingStartedProj
{
    public static class MyFunctions
    {
        [ExcelFunction(Description = "My first .NET function")]
        public static string SayHello(string name)
        {
            return "Hello " + name;
        }

        [ExcelFunction(Description = "My first .NET function")]
        public static void SayHello()
        {
            ExcelApp xlsApp = (ExcelApp)ExcelDnaUtil.Application;

            Workbook wb = xlsApp.ActiveWorkbook;
            if (wb == null)
                return;

            //Worksheet ws = wb.Worksheets.Add(Type: XlSheetType.xlWorksheet);
            Worksheet ws = wb.ActiveSheet;
            ws.Range["A1"].Value = "Hello! :)";

            List<int> myValues = new List<int>();

            for (int ii = 0; ii < 100; ii++)
            {
                myValues.Add(ii);
            }

            // Export results to Excel
            {
                // Generally it's faster to write an array to a range
                var finalArray = new object[myValues.Count, 1];
                int ii = 0;
                foreach (var item in myValues)
                {
                    finalArray[ii, 0] = item;
                    ii++;
                }
                ws.Range["A2"].Resize[100, 1].Value = finalArray;
            }
        }
    }
}
