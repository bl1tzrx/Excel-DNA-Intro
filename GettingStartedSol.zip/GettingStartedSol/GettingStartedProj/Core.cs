﻿using ExcelDna.Integration.CustomUI;
using System.Runtime.InteropServices;

namespace GettingStartedProj
{
    public class Core
    {
        [ComVisible(true)]
        public class RibbonController : ExcelRibbon
        {
            public override string GetCustomUI(string RibbonID)
            {
                return @"
          <customUI xmlns='http://schemas.microsoft.com/office/2006/01/customui'>
          <ribbon>
            <tabs>
              <tab id='tab1' label='My Tab1'>
                <group id='group1' label='My Group1'>
                  <button id='button1' label='My Button1' onAction='OnButtonPressed'/>
                </group >
              </tab>

            </tabs>
          </ribbon>
        </customUI>";
            }

            public void OnButtonPressed(IRibbonControl control)
            {
                MessageBox.Show("Hello from control " + control.Id);
                MyFunctions.SayHello();
            }
        }
    }
}